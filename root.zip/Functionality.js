document.getElementById('calculateButton').addEventListener('click', calculateLoan);

function calculateLoan() {
    const loanAmount = parseFloat(document.getElementById('loanAmount').value);
    const interestRate = parseFloat(document.getElementById('interestRate').value) / 100 / 12;
    const loanTerm = parseFloat(document.getElementById('loanTerm').value) * 12;

    if (isNaN(loanAmount) || isNaN(interestRate) || isNaN(loanTerm) || loanTerm <= 0) {
        document.getElementById('result').innerText = "Please enter valid values.";
        return;
    }

    const monthlyPayment = (loanAmount * interestRate) / (1 - Math.pow(1 + interestRate, -loanTerm));
    document.getElementById('result').innerText = `Monthly Payment: $${monthlyPayment.toFixed(2)}`;
}
document.getElementById('mpgCalculateButton').addEventListener('click', function() {
    const milesDriven = parseFloat(document.getElementById('milesDriven').value);
    const gallonsUsed = parseFloat(document.getElementById('gallonsUsed').value);
    const mpgResult = document.getElementById('mpgResult');

    if (gallonsUsed === 0) {
        mpgResult.textContent = "Gallons used cannot be zero.";
        return;
    }

    const mpg = milesDriven / gallonsUsed;
    mpgResult.textContent = `Your MPG is: ${mpg.toFixed(2)}`;
});